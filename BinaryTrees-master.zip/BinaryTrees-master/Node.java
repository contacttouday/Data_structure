package trees;

public class Node {

	int data;
	Node left;
	Node rigth;
}
