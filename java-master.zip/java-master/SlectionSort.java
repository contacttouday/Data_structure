package interviewquestions;

public class SlectionSort 
{
	public static void main(String[] args) 
	{
		int a[]= {1,3,4,65,4,3,6,5,3,-3};
			for(int i=0;i<a.length;i++)
			{
				for(int j=i+1;j<a.length;j++)
				{
					
				}
			}
		}

}
