import java.util.*;
public class SpiralMatrix 
{
	public static void main(String args[])
	{
		
	}
	
}
