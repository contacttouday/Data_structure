import java.util.*;
public class StringBufferExamples 
{
	public static void main(String []args)
	{
		StringBuffer sb =new StringBuffer("uday veer singh");
		System.out.println(sb.reverse());
		
		
	}
	
}
