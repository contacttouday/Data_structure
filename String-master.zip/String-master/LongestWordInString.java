package string;

public class LongestWordInString {

}
