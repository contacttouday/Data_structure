package linkedlist;


public class GetSize {
//	public int getSize() {
//		Node temp=head;
//		int count=0;
//		while(temp!=null){
//			temp=temp.next;
//			count++;
//		}
//		return count;
//	}

}