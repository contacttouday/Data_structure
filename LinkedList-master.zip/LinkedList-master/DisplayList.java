package linkedlist;


public class DisplayList {

	
//	public void displayList() {
//		Node temp=head;
//		while(temp!=null) {
//			System.out.print(temp.data+"-->");
//			temp=temp.next;
//		}
//		System.out.print(temp);
//	}
}
